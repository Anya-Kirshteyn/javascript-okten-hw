let firstName="Anya"
let middleName="Vitaliivna"
let lastName="Kirshteyn"
let person= `${firstName} ${middleName} ${lastName}`
console.log(person)