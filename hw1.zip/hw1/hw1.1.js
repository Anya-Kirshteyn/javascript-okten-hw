let a='hello'
let b='owu'
let c='com';
let d='ua';
let e=1;
let f=10;
let g=-999;
let h=123;
let i=3.14;
let j=2.7;
let k=16;
let t=true;
let ff=false
 let hw1=`${a} ${b} ${c} ${d} ${e} ${f} ${g} ${h} ${h} ${i} ${j} ${k} ${k} ${t} ${ff}`;
console.log(hw1)